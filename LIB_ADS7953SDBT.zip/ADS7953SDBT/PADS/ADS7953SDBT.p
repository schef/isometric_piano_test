*PADS-LIBRARY-PART-TYPES-V9*

ADS7953SDBT SOP50P640X120-38N I ANA 7 1 0 0 0
TIMESTAMP 2026.09.10.17.41.24
"Mouser Part Number" 595-ADS7953SDBT
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/ADS7953SDBT?qs=Lv5%252BaqTFJEONyN32QUOVhg%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" ADS7953SDBT
"Description" 12-Bit, 1-MSPS, 16-Channel, Single-Ended, microPower SAR ADC with Serial I/F
"Datasheet Link" http://www.ti.com/lit/gpn/ads7953
"Geometry.Height" 1.2mm
GATE 1 38 0
ADS7953SDBT
1 0 U GPIO2
2 0 U GPIO3
3 0 U REFM
4 0 U REFP
5 0 U +VA_1
6 0 U AGND_1
7 0 U MXO
8 0 U AINP
9 0 U AINM
10 0 U AGND_2
11 0 U CH15
12 0 U CH14
13 0 U CH13
14 0 U CH12
15 0 U CH11
16 0 U CH10
17 0 U CH9
18 0 U CH8
19 0 U AGND_3
38 0 U GPIO1
37 0 U GPIO0
36 0 U +VBD
35 0 U BDGND
34 0 U SDO
33 0 U SDI
32 0 U SCLK
31 0 U \CS
30 0 U AGND_5
29 0 U +VA_2
28 0 U CH0
27 0 U CH1
26 0 U CH2
25 0 U CH3
24 0 U CH4
23 0 U CH5
22 0 U CH6
21 0 U CH7
20 0 U AGND_4

*END*
*REMARK* SamacSys ECAD Model
747719/1647200/2.50/38/3/Integrated Circuit
